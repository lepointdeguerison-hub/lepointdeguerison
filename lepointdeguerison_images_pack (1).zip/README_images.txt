Pack illustrations — Le Point de Guérison
-------------------------------------------
Ces 5 images sont générées (motifs géométriques/illustrations simples). Vous pouvez les utiliser librement.
Placez-les dans le dossier: images/

- hero.jpg            (Accueil)
- hypnose.jpg         (Section Hypnose)
- pnl.jpg             (Section PNL)
- energie.jpg         (Section Soins énergétiques/Reiki)
- massage.jpg         (Section Massage énergétique)

Intégration:
1) Créez le dossier images/ dans votre dépôt GitHub.
2) Uploadez-y ces fichiers .jpg.
3) Votre index.html les affichera automatiquement.
